package com.cg.project.service;

public interface IBankingService
{

}
