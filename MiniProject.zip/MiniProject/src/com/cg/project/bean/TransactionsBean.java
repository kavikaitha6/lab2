package com.cg.project.bean;

import java.util.Date;

public class TransactionsBean {
private long transactionId;
private String transDescription;
private Date dateOfTransaction;
private String transactionType;
private double transactionAmount;
private long accountNumber;

public TransactionsBean() {
	super();
}
public long getTransactionId() {
	return transactionId;
}
public void setTransactionId(long transactionId) {
	this.transactionId = transactionId;
}
public String getTransDescription() {
	return transDescription;
}
public void setTransDescription(String transDescription) {
	this.transDescription = transDescription;
}
public Date getDateOfTransaction() {
	return dateOfTransaction;
}
public void setDateOfTransaction(Date dateOfTransaction) {
	this.dateOfTransaction = dateOfTransaction;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public Double getTransactionAmount() {
	return transactionAmount;
}
public void setTransactionAmount(Double transactionAmount) {
	this.transactionAmount = transactionAmount;
}
public long getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(long accountNumber) {
	this.accountNumber = accountNumber;
}

}
