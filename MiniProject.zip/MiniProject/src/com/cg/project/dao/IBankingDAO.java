package com.cg.project.dao;

public interface IBankingDAO 
{

}
