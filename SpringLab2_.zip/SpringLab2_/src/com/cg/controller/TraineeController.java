package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.TraineeBean;
import com.cg.dao.TraineeDAOImpl;
import com.cg.service.TraineeServiceImpl;

@Controller
public class TraineeController {
	static TraineeBean trainee = new TraineeBean();
	//TraineeServiceImpl service = new TraineeServiceImpl();
	//bean of id: dao called
	//static TraineeBean trainee = new TraineeBean();
	TraineeDAOImpl dao = new TraineeDAOImpl();
	TraineeServiceImpl service = new TraineeServiceImpl();
//********* add trainee **************
	
@RequestMapping("/TraineeAdd")
public ModelAndView TraineeAdd()
{
   // form data is requested in object of TraineeBean	
	return new ModelAndView("AddTrainee"); // open list operations jsp again ....
}


@RequestMapping(value="/addtrainee",method=RequestMethod.POST)
public String AddTrainee(@RequestParam("id") String id,@RequestParam("name") String name,@RequestParam("location") String location,@RequestParam("domain") String domain,Model model)
{   
	System.out.println(id+name+domain+location);
	//trainee = null;
	//TraineeBean trainee = new TraineeBean();
model.addAttribute("id",id);
model.addAttribute("name",name);
model.addAttribute("location",location);
model.addAttribute("domain",domain);
	//service.addTrainee(trainee); //jpa query
	return "TraineeDetails";
}




/*
// *********** delete trainee *****************
@RequestMapping("/TraineeDelete")
public ModelAndView TraineeDelete()
{
	return new ModelAndView("DeleteTrainee"); //call for DeleteTrainee jsp ...
}

@RequestMapping(value="/deltrain",method=RequestMethod.POST)
public ModelAndView Deltrainee(@ModelAttribute("id") int id)
{
	//dao.delete(id);
	TraineeBean trainee = dao.removeTrainee(id); // fetch details for id .... to delete
	return new ModelAndView("TraineeInfoDel","trainee",trainee); 
}

@RequestMapping(value="/del/{id}",method=RequestMethod.POST)
public ModelAndView Delete(@PathVariable int id)
{
	//dao.delete(id);
	int status = dao.delete(id); 
	return new ModelAndView("redirect:/traineeMS"); 
}

//************* update trainee ***************
@RequestMapping("/TraineeModify")
public ModelAndView TraineeUpdate()
{
	return new ModelAndView("ModifyTrainee"); //call for ModifyTrainee jsp ...
}

@RequestMapping(value="/modtrain",method=RequestMethod.POST)
public ModelAndView Modtrainee(@ModelAttribute("id") int id)
{
	
	TraineeBean trainee = dao.fetch(id); // fetch details for id .... to modify
	return new ModelAndView("TraineeInfoUpdate","trainee",trainee); 
}

@RequestMapping(value="/update/{trainee}",method=RequestMethod.POST)
public ModelAndView Update(@PathVariable TraineeBean trainee)
{
	//dao.delete(id);
	int status = dao.update(trainee); // 
	return new ModelAndView("redirect:/traineeMS"); 
}

//*********** retrieve trainee **************
@RequestMapping("/TraineeRetrieve")
public ModelAndView TraineeRetrieve()
{
	return new ModelAndView("RetrieveTrainee"); //call for ModifyTrainee jsp ...
}

@RequestMapping(value="/retrieve",method=RequestMethod.POST)
public ModelAndView Retrievetrainee(@ModelAttribute("id") int id)
{
	TraineeBean trainee = dao.fetch(id); // fetch details for id .... to modify
	//int status = dao.retrieve(trainee);
	return new ModelAndView("TraineeInfoRetrieve","trainee",trainee); 
}

//************** retrieve all trainee***************
@RequestMapping("/TraineeRetrieveAll")
public ModelAndView TraineeRetrieveAll()
{
	return new ModelAndView("RetrieveTrainee"); //call for ModifyTrainee jsp ...
}
*/




}
