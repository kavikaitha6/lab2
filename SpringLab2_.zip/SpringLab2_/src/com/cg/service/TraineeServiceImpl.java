package com.cg.service;

import com.cg.bean.TraineeBean;
import com.cg.dao.TraineeDAOImpl;

public class TraineeServiceImpl {

	private TraineeDAOImpl dao;

	public TraineeServiceImpl() {
		dao = new TraineeDAOImpl();
	}

	//@Override
	public void addTrainee(TraineeBean traineeBean) {
		dao.beginTransaction();
		dao.addTrainee(traineeBean);
		dao.commitTransaction();
	}
	
	public void retrieveTraineeById(int id)
	{   dao.beginTransaction();
		dao.retrieveTraineeById(id);
		dao.beginTransaction();
	}
	
	public void retrieveAllTrainees()
	{
		dao.retrieveAllTrainees();
	}
	
	public void removeTrainee(TraineeBean traineeBean)
	{
		dao.beginTransaction();
		dao.removeTrainee(traineeBean);
		dao.commitTransaction();
	}
	
	public void modifyTrainee(TraineeBean traineeBean)
	{
		dao.beginTransaction();
		dao.modifyTrainee(traineeBean);
		dao.commitTransaction();
	}
}
