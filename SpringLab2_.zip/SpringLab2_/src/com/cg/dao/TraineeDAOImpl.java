package com.cg.dao;

import java.awt.print.Book;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.TraineeBean;

@Repository
public class TraineeDAOImpl {

	private EntityManager entityManager;

	public TraineeDAOImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	//@Override
	public TraineeBean retrieveTraineeById(int id) {
		TraineeBean trainee = entityManager.find(TraineeBean.class, id);
		return trainee;
	}

	public void modifyTrainee(TraineeBean trainee)
	{
		entityManager.merge(trainee);
	}
	public void removeTrainee(TraineeBean trainee)
	{
		entityManager.remove(trainee);
	}
	
	public void addTrainee(TraineeBean trainee)
	{
		entityManager.persist(trainee);
	}
	
	//@Override
	public List<TraineeBean> retrieveAllTrainees() {
		String qStr= "SELECT trainee FROM TraineeBean trainee";
		TypedQuery<TraineeBean> query = entityManager.createQuery(qStr,TraineeBean.class);
		List<TraineeBean> traineeList = query.getResultList();
		return traineeList;
	}

	//@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	//@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	
	
	
}
