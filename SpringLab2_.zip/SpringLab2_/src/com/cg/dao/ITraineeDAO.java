package com.cg.dao;

public class ITraineeDAO {

}
